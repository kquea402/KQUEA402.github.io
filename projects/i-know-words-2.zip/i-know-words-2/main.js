window.onload = function() {
    document.getElementById("my_audio").autoplay()
}